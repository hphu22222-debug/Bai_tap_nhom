import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime

from pathlib import Path
DB = str(Path(__file__).with_name("shop.db"))

def connect():
    return sqlite3.connect(DB)

def init_db():
    con = connect()
    cur = con.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS products(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        price INTEGER NOT NULL,
        stock INTEGER NOT NULL
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS orders(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer TEXT NOT NULL,
        phone TEXT NOT NULL,
        address TEXT NOT NULL,
        payment TEXT NOT NULL,
        total INTEGER NOT NULL,
        status TEXT NOT NULL,
        created_at TEXT NOT NULL
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS order_items(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        product_name TEXT NOT NULL,
        qty INTEGER NOT NULL,
        price INTEGER NOT NULL
    )""")
    if cur.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 0:
        cur.executemany("INSERT INTO products(name,price,stock) VALUES(?,?,?)", [
            ("Tai nghe Bluetooth", 350000, 10),
            ("Chuột không dây", 220000, 8),
            ("Bàn phím cơ", 690000, 5),
            ("Sạc nhanh 20W", 290000, 12),
            ("Cáp USB-C", 120000, 15)
        ])
    con.commit()
    con.close()

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Demo Topic 7 - Hệ thống đặt hàng")
        self.geometry("1200x780")
        self.minsize(900, 560)
        self.cart = {}
        self.style = ttk.Style(self)
        try:
            self.style.theme_use("clam")
        except:
            pass
        self.build()

    def build(self):
        header = tk.Frame(self, bg="#17365D", height=65)
        header.pack(fill="x")
        tk.Label(header, text="DEMO HỆ THỐNG ĐẶT HÀNG", fg="white",
                 bg="#17365D", font=("Arial", 18, "bold")).pack(side="left", padx=22, pady=17)
        tk.Label(header, text="Python • Tkinter • SQLite", fg="white",
                 bg="#17365D", font=("Arial", 10)).pack(side="right", padx=22)

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=12, pady=12)
        self.customer_tab = ttk.Frame(self.tabs)
        self.staff_tab = ttk.Frame(self.tabs)
        self.tabs.add(self.customer_tab, text="  KHÁCH HÀNG  ")
        self.tabs.add(self.staff_tab, text="  NHÂN VIÊN  ")
        self.build_customer()
        self.build_staff()

    def money(self, n):
        return f"{n:,} đ".replace(",", ".")

    def build_customer(self):
        left = ttk.Frame(self.customer_tab, padding=10)
        left.pack(side="left", fill="both", expand=True)
        right = ttk.Frame(self.customer_tab, padding=10)
        right.pack(side="right", fill="both", expand=True)

        ttk.Label(left, text="1. Chọn sản phẩm", font=("Arial", 14, "bold")).pack(anchor="w")
        self.product_tree = ttk.Treeview(left, columns=("name","price","stock"), show="headings", height=11)
        for c, t, w in [("name","Sản phẩm",210),("price","Giá",110),("stock","Tồn kho",70)]:
            self.product_tree.heading(c, text=t)
            self.product_tree.column(c, width=w, anchor="center" if c!="name" else "w")
        self.product_tree.pack(fill="x", pady=8)
        self.qty_var = tk.IntVar(value=1)
        ttk.Label(left, text="Số lượng (có thể nhập vượt kho để thử nhánh thiếu hàng)").pack(anchor="w")
        ttk.Spinbox(left, from_=1, to=999, textvariable=self.qty_var, width=10).pack(anchor="w")
        ttk.Button(left, text="Thêm vào giỏ", command=self.add_cart).pack(anchor="e")
        ttk.Label(left, text="Giỏ hàng", font=("Arial", 13, "bold")).pack(anchor="w", pady=(18,4))
        self.cart_tree = ttk.Treeview(left, columns=("name","qty","total"), show="headings", height=7)
        for c,t,w in [("name","Sản phẩm",210),("qty","SL",60),("total","Thành tiền",120)]:
            self.cart_tree.heading(c,text=t); self.cart_tree.column(c,width=w,anchor="center" if c!="name" else "w")
        self.cart_tree.pack(fill="x")
        ttk.Button(left, text="Xóa sản phẩm", command=self.remove_cart).pack(anchor="e", pady=6)
        self.total_label = ttk.Label(left, text="Tổng: 0 đ", font=("Arial", 13, "bold"))
        self.total_label.pack(anchor="e", pady=5)

        ttk.Label(right, text="2. Thông tin đặt hàng", font=("Arial",14,"bold")).pack(anchor="w")
        form = ttk.Frame(right); form.pack(fill="x", pady=10)
        self.name_var, self.phone_var, self.address_var = tk.StringVar(), tk.StringVar(), tk.StringVar()
        for i,(lab,var) in enumerate([("Họ tên",self.name_var),("Số điện thoại",self.phone_var),("Địa chỉ",self.address_var)]):
            ttk.Label(form,text=lab).grid(row=i,column=0,sticky="w",pady=7)
            ttk.Entry(form,textvariable=var,width=38).grid(row=i,column=1,sticky="ew",padx=10,pady=7)
        form.columnconfigure(1,weight=1)
        ttk.Label(right,text="3. Thanh toán",font=("Arial",14,"bold")).pack(anchor="w",pady=(12,5))
        self.payment = tk.StringVar(value="COD")
        ttk.Radiobutton(right,text="Thanh toán khi nhận hàng (COD)",variable=self.payment,value="COD").pack(anchor="w")
        ttk.Radiobutton(right,text="Chuyển khoản",variable=self.payment,value="Chuyển khoản").pack(anchor="w")
        ttk.Radiobutton(right,text="Mô phỏng thanh toán lỗi",variable=self.payment,value="FAIL").pack(anchor="w")
        ttk.Button(right,text="GỬI YÊU CẦU ĐẶT HÀNG / GIỮ HÀNG",command=self.place_order).pack(fill="x",pady=22,ipady=8)
        ttk.Label(right,text="Có kiểm tra: giỏ trống • thiếu thông tin • hết hàng • thanh toán lỗi",
                  foreground="#555").pack(anchor="w")
        self.refresh_products()
        self.refresh_cart()

    def build_staff(self):
        top = ttk.Frame(self.staff_tab,padding=10); top.pack(fill="both",expand=True)
        bar = ttk.Frame(top); bar.pack(fill="x")
        ttk.Label(bar,text="Quản lý đơn hàng",font=("Arial",14,"bold")).pack(side="left")
        ttk.Button(bar,text="Làm mới",command=self.refresh_orders).pack(side="right")
        self.order_tree = ttk.Treeview(top,columns=("id","customer","phone","total","status","date"),
                                       show="headings",height=15)
        for c,t,w in [("id","Mã đơn",70),("customer","Khách hàng",160),("phone","SĐT",110),
                      ("total","Tổng tiền",120),("status","Trạng thái",130),("date","Thời gian",150)]:
            self.order_tree.heading(c,text=t); self.order_tree.column(c,width=w,anchor="center")
        self.order_tree.pack(fill="both",expand=True,pady=10)
        btns=ttk.Frame(top); btns.pack(fill="x")
        ttk.Button(btns,text="Xem chi tiết",command=self.order_detail).pack(side="left")
        ttk.Button(btns,text="XỬ LÝ THANH TOÁN",command=self.confirm_order).pack(side="right")
        ttk.Button(btns,text="CHUẨN BỊ VÀ GIAO HÀNG",command=lambda: self.advance_order("Đã thanh toán", "Đang giao hàng")).pack(side="right", padx=8)
        ttk.Button(btns,text="KHÁCH XÁC NHẬN NHẬN",command=lambda: self.advance_order("Đang giao hàng", "Hoàn tất")).pack(side="right", padx=8)
        ttk.Button(btns,text="Hủy đơn / trả hàng về kho",command=self.cancel_order).pack(side="left", padx=8)
        ttk.Label(top,text="LUỒNG: Chọn sản phẩm → Nhập giao hàng → Gửi yêu cầu → Kiểm tra kho → Giữ hàng → Thanh toán → Giao hàng → Xác nhận nhận",wraplength=1100).pack(fill="x",pady=12)
        ttk.Label(top,text="Chọn đơn và dùng các nút theo thứ tự. COD: xử lý phương thức trước khi giao; thu tiền khi khách nhận. Thanh toán và vận chuyển là mô phỏng.",wraplength=1100).pack(fill="x")
        self.refresh_orders()

    def refresh_products(self):
        for x in self.product_tree.get_children(): self.product_tree.delete(x)
        con=connect()
        for pid,name,price,stock in con.execute("SELECT id,name,price,stock FROM products"):
            self.product_tree.insert("", "end", iid=str(pid), values=(name,self.money(price),stock))
        con.close()

    def add_cart(self):
        sel=self.product_tree.selection()
        if not sel: return messagebox.showwarning("Thông báo","Hãy chọn sản phẩm.")
        pid=int(sel[0]); con=connect()
        row=con.execute("SELECT name,price,stock FROM products WHERE id=?",(pid,)).fetchone(); con.close()
        name,price,stock=row
        try:
            extra = self.qty_var.get()
            if extra < 1: raise ValueError()
        except (ValueError, tk.TclError):
            return messagebox.showwarning("Số lượng", "Nhập số nguyên dương.")
        qty=self.cart.get(pid,{}).get("qty",0)+extra
        self.cart[pid]={"name":name,"price":price,"qty":qty}
        self.refresh_cart()

    def remove_cart(self):
        sel=self.cart_tree.selection()
        if sel:
            self.cart.pop(int(sel[0]),None); self.refresh_cart()

    def refresh_cart(self):
        for x in self.cart_tree.get_children(): self.cart_tree.delete(x)
        total=0
        for pid,item in self.cart.items():
            sub=item["price"]*item["qty"]; total+=sub
            self.cart_tree.insert("","end",iid=str(pid),values=(item["name"],item["qty"],self.money(sub)))
        self.total_label.config(text=f"Tổng: {self.money(total)}")

    def place_order(self):
        if not self.cart: return messagebox.showwarning("Giỏ hàng trống","Vui lòng chọn ít nhất một sản phẩm.")
        if not all([self.name_var.get().strip(),self.phone_var.get().strip(),self.address_var.get().strip()]):
            return messagebox.showwarning("Thiếu thông tin","Vui lòng nhập đầy đủ họ tên, SĐT và địa chỉ.")
        con=connect(); cur=con.cursor()
        try:
            cur.execute("BEGIN IMMEDIATE")
            for pid,item in self.cart.items():
                stock=cur.execute("SELECT stock FROM products WHERE id=?",(pid,)).fetchone()[0]
                if item["qty"]>stock:
                    raise ValueError(f"{item['name']} không đủ tồn kho.")
            total=sum(x["price"]*x["qty"] for x in self.cart.values())
            cur.execute("""INSERT INTO orders(customer,phone,address,payment,total,status,created_at)
                           VALUES(?,?,?,?,?,?,?)""",
                        (self.name_var.get().strip(),self.phone_var.get().strip(),self.address_var.get().strip(),
                         self.payment.get(),total,"Chờ thanh toán",datetime.now().strftime("%d/%m/%Y %H:%M")))
            oid=cur.lastrowid
            for pid,item in self.cart.items():
                cur.execute("""INSERT INTO order_items(order_id,product_id,product_name,qty,price)
                               VALUES(?,?,?,?,?)""",(oid,pid,item["name"],item["qty"],item["price"]))
                cur.execute("UPDATE products SET stock=stock-? WHERE id=?",(item["qty"],pid))
            con.commit()
        except Exception as e:
            con.rollback(); con.close(); return messagebox.showerror("Lỗi",str(e))
        con.close()
        messagebox.showinfo("Đặt hàng thành công",
                            f"Mã đơn: DH{oid:03d}\nTổng tiền: {self.money(total)}\nTrạng thái: Chờ thanh toán - đã giữ hàng")
        self.cart.clear(); self.refresh_cart(); self.refresh_products(); self.refresh_orders()
        self.name_var.set(""); self.phone_var.set(""); self.address_var.set("")

    def refresh_orders(self):
        for x in self.order_tree.get_children(): self.order_tree.delete(x)
        con=connect()
        for oid,cus,phone,total,status,date in con.execute(
            "SELECT id,customer,phone,total,status,created_at FROM orders ORDER BY id DESC"):
            self.order_tree.insert("","end",iid=str(oid),
                values=(f"DH{oid:03d}",cus,phone,self.money(total),status,date))
        con.close()

    def advance_order(self, expected, target):
        sel=self.order_tree.selection()
        if not sel: return messagebox.showwarning("Thông báo", "Hãy chọn một đơn hàng.")
        oid=int(sel[0])
        with connect() as con:
            changed=con.execute("UPDATE orders SET status=? WHERE id=? AND status=?", (target,oid,expected)).rowcount
        if not changed:
            return messagebox.showwarning("Sai bước", f"Đơn phải có trạng thái: {expected}.")
        self.refresh_orders()
        messagebox.showinfo("Thành công", f"DH{oid:03d}: {target}")

    def confirm_order(self):
        sel=self.order_tree.selection()
        if not sel: return messagebox.showwarning("Thông báo", "Hãy chọn một đơn hàng.")
        oid=int(sel[0])
        with connect() as con:
            payment,status=con.execute("SELECT payment,status FROM orders WHERE id=?",(oid,)).fetchone()
        if status != "Chờ thanh toán":
            return messagebox.showwarning("Sai bước", "Chỉ thanh toán đơn đang chờ thanh toán.")
        if payment == "FAIL":
            if not messagebox.askyesno("Thanh toán thất bại", "Giao dịch mô phỏng thất bại. Đơn vẫn giữ hàng. Đổi sang chuyển khoản và thử lại?"):
                return
            with connect() as con:
                con.execute("UPDATE orders SET payment='Chuyển khoản' WHERE id=?",(oid,))
        self.advance_order("Chờ thanh toán", "Đã thanh toán")

    def cancel_order(self):
        sel=self.order_tree.selection()
        if not sel: return messagebox.showwarning("Thông báo", "Hãy chọn một đơn hàng.")
        oid=int(sel[0])
        with connect() as con:
            con.execute("BEGIN IMMEDIATE")
            status=con.execute("SELECT status FROM orders WHERE id=?",(oid,)).fetchone()[0]
            if status not in ("Chờ thanh toán", "Đã thanh toán"):
                return messagebox.showwarning("Không thể hủy", "Chỉ hủy trước khi giao hàng.")
            for pid,qty in con.execute("SELECT product_id,qty FROM order_items WHERE order_id=?",(oid,)):
                con.execute("UPDATE products SET stock=stock+? WHERE id=?",(qty,pid))
            con.execute("UPDATE orders SET status='Đã hủy' WHERE id=?",(oid,))
        self.refresh_orders(); self.refresh_products()
        messagebox.showinfo("Đã hủy", "Đã trả lượng hàng giữ về kho. Hoàn tiền thực tế nằm ngoài demo.")

    def order_detail(self):
        sel=self.order_tree.selection()
        if not sel: return messagebox.showwarning("Thông báo","Hãy chọn một đơn hàng.")
        oid=int(sel[0]); con=connect()
        o=con.execute("SELECT customer,phone,address,payment,total,status,created_at FROM orders WHERE id=?",(oid,)).fetchone()
        items=con.execute("SELECT product_name,qty,price FROM order_items WHERE order_id=?",(oid,)).fetchall()
        con.close()
        lines=[f"Mã đơn: DH{oid:03d}",f"Khách: {o[0]}",f"SĐT: {o[1]}",f"Địa chỉ: {o[2]}",
               f"Thanh toán: {o[3]}",f"Trạng thái: {o[5]}",f"Thời gian: {o[6]}","","Sản phẩm:"]
        for name,qty,price in items:
            lines.append(f"- {name} x{qty}: {self.money(qty*price)}")
        lines += ["",f"TỔNG: {self.money(o[4])}"]
        messagebox.showinfo("Chi tiết đơn hàng","\n".join(lines))

if __name__=="__main__":
    init_db()
    App().mainloop()
