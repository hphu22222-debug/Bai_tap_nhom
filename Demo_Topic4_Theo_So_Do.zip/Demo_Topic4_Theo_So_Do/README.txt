DEMO TOPIC 7 - LUỒNG ĐẶT HÀNG THEO SƠ ĐỒ

CÁCH CHẠY (Python 3, Tkinter, SQLite; không cần pip):
Giải nén, mở thư mục và chạy: python main.py
Windows: có thể nhấp đúp Chay_Demo.bat.

KỊCH BẢN 1 - THÀNH CÔNG:
1. Tab KHÁCH HÀNG: chọn sản phẩm, nhập số lượng, thêm vào giỏ.
2. Nhập họ tên, số điện thoại, địa chỉ; chọn chuyển khoản.
3. Gửi yêu cầu: kiểm tra toàn bộ giỏ, tạo đơn và trừ kho để giữ hàng.
4. Tab NHÂN VIÊN: chọn đơn, XỬ LÝ THANH TOÁN.
5. CHUẨN BỊ VÀ GIAO HÀNG.
6. KHÁCH XÁC NHẬN NHẬN: đơn Hoàn tất.

KỊCH BẢN 2 - THIẾU HÀNG:
Chọn Bàn phím cơ, nhập 6 khi tồn kho là 5, thêm giỏ rồi gửi yêu cầu.
Ứng dụng thông báo thiếu hàng, không tạo đơn, không trừ kho.
Xóa sản phẩm trong giỏ rồi đổi sản phẩm/số lượng để thử lại.

KỊCH BẢN 3 - THANH TOÁN LỖI:
Chọn Mô phỏng thanh toán lỗi trước khi gửi yêu cầu.
Đơn được tạo và giữ hàng. Khi xử lý thanh toán sẽ báo thất bại.
Chọn Có để đổi sang chuyển khoản, hoặc Không để giữ trạng thái chờ.
Có thể hủy trước giao hàng để trả kho. Không hủy hai lần.

COD: trạng thái Đã thanh toán biểu thị bước xử lý/chấp nhận phương thức;
việc thu tiền diễn ra khi nhận hàng. Thanh toán, giao hàng đều là mô phỏng,
không kết nối ngân hàng hay hãng vận chuyển, không phải website online.

Dữ liệu tự lưu ở shop.db cạnh main.py. Gói mới không kèm dữ liệu đơn cũ.
Muốn chạy lại từ đầu: đóng ứng dụng, xóa shop.db rồi mở lại.
main.py chứa giao diện và xử lý để bạn phát triển thêm.
